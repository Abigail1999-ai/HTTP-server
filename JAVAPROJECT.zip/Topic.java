package test;
import java.util.ArrayList;
import java.util.List;

public class Topic{
	public final String name;
    private final List<Agent> subs = new ArrayList<>();
    private final List<Agent> pubs = new ArrayList<>();
    
    public Topic (String name) {
    	this.name=name;
    }
	public void subscribe(Agent agent) {
        if (!subs.contains(agent)) {
            subs.add(agent);
        }
	}
	public void unsubscribe(Agent agent) {
            subs.remove(agent);
        }
	public void publish(Message m) {
		for (Agent agent :new ArrayList<> (subs)) {
			agent.callback(name,m) ;
		}
	}

	
	public void removePublisher(Agent agent) {
        if (!pubs.contains(agent)) {
        	pubs.remove(agent);
        }

	}
	public void addPublisher(Agent agent) {
        if (!pubs.contains(agent)) {
         pubs.add(agent);
	}
}
	public List<Agent> getSubscribers() {
        return subs;
    }

    public List<Agent> getPublishers() {
        return pubs;
    }
	}
