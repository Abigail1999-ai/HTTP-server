package test;


public class IncAgent implements Agent{
double x=0;
String [] pubs;
String [] subs;
String name;
public IncAgent(String [] subs,String [] pubs)
{
	this.subs=subs;
	this.pubs=pubs;
	TopicManagerSingleton.TopicManager newAgent=TopicManagerSingleton.get();
	newAgent.getTopic(subs[0]).subscribe(this);
	newAgent.getTopic(pubs[0]).addPublisher(this);
}
	@Override
	public String getName() {
		return name;
	}

	@Override
	public void reset() {
		x=0;
		
	}

	@Override
	public void callback(String topic, Message msg) {
		if(topic.equals(subs[0])) {
			x=msg.asDouble;
		}
		if(!Double.isNaN(x)) {
			double sum =x+1;
			TopicManagerSingleton.get().getTopic(pubs[0]).publish(new Message(sum));
		}
		
	}

	@Override
	public void close() {
		TopicManagerSingleton.TopicManager newAgent=TopicManagerSingleton.get();
		newAgent.getTopic(subs[0]).unsubscribe(this);
		newAgent.getTopic(pubs[0]).removePublisher(this);
		
	}
}