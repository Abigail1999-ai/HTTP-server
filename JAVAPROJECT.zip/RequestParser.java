package test;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RequestParser {

    public static RequestInfo parseRequest(BufferedReader reader) throws IOException {
        RequestInfo ri = new RequestInfo();

        String line = reader.readLine();
        if (line == null || line.isEmpty()) return null;

        String[] parts = line.split(" ");
        ri.command = parts[0];
        ri.uri = parts[1];

        String uriOnly = ri.uri;
        String paramString = null;
        if (ri.uri.contains("?")) {
            int idx = ri.uri.indexOf('?');
            uriOnly = ri.uri.substring(0, idx);
            paramString = ri.uri.substring(idx + 1);
        }

        List<String> segments = new ArrayList<>();
        for (String seg : uriOnly.split("/")) {
            if (!seg.isEmpty()) segments.add(seg);
        }
        ri.uriParts = segments.toArray(new String[0]);

        if (paramString != null) {
            String[] pairs = paramString.split("&");
            for (String pair : pairs) {
                String[] kv = pair.split("=");
                if (kv.length == 2) {
                    ri.params.put(kv[0], kv[1]);
                }
            }
        }

        int contentLength = 0;
        while ((line = reader.readLine()) != null && !line.isEmpty()) {
            if (line.toLowerCase().startsWith("content-length:")) {
                contentLength = Integer.parseInt(line.split(":")[1].trim());
            }
        }

        
        while ((line = reader.readLine()) != null && !line.isEmpty()) {
            String[] kv = line.split("=");
            if (kv.length == 2) {
                ri.params.put(kv[0].trim(), kv[1].trim());
            }
        }

        if (contentLength > 0) {
            char[] buffer = new char[contentLength];
            int read = reader.read(buffer);
            ri.content = new String(buffer, 0, read).getBytes();
        } else {
            ri.content = new byte[0];
        }

        return ri;
    }

    public static class RequestInfo {
        public String command;
        public String uri;
        public String[] uriParts;
        public Map<String, String> params = new HashMap<>();
        public byte[] content;

        public String getHttpCommand() {
            return command;
        }

        public String getUri() {
            return uri;
        }

        public String[] getUriSegments() {
            return uriParts;
        }

        public Map<String, String> getParameters() {
            return params;
        }

        public byte[] getContent() {
            return content;
        }
    }
}