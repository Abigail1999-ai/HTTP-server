package test;


public class ParallelAgent implements Agent{
Agent agent1;
	public ParallelAgent(Agent agent)
	{
		this.agent1=agent;
	}
	@Override
	public String getName() {
		return agent1.getName();
	}

	@Override
	public void reset() {
		agent1.reset();
		
	}

	@Override
	public void callback(String topic, Message msg) {
		agent1.callback(topic,msg);
		
	}

	@Override
	public void close() {
		agent1.close();
		
	}
    

}
