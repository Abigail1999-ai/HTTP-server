package test;

import java.util.ArrayList;
import java.util.List;


public class Node {
	private String name;
    private List<Node> edges;
    private Message msg;
    
    public Node(String name) {
		super();
		this.name = name;
		this.edges = new ArrayList<>();;
		this.msg = null;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Node> getEdges() {
		return edges;
	}
	public void setEdges(List<Node> edges) {
		this.edges = edges;
	}
	public Message getMsg() {
		return msg;
	}
	public void setMsg(Message msg) {
		this.msg = msg;
	}
	public void addEdge(Node node) {
        if (!edges.contains(node)) {
            edges.add(node);
        }

	}
	public boolean hasCycles() {
        return hasCyclesHelper(new ArrayList<>());
    }
    private boolean hasCyclesHelper(List<Node> visited) {
        if (visited.contains(this)) {
            return true;
        }

        visited.add(this);
        for (Node neighbor : edges) {
            if (neighbor.hasCyclesHelper(new ArrayList<>(visited))) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "Node(" + name + ")";
    }

}
  